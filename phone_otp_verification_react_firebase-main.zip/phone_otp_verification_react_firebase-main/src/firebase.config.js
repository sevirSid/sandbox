// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyDIMp4EXMBFf67GPQO39_DWusWlTWloO30",
  authDomain: "authdbapp.firebaseapp.com",
  projectId: "authdbapp",
  storageBucket: "authdbapp.appspot.com",
  messagingSenderId: "422427127081",
  appId: "1:422427127081:web:ee817c1e4d861688ca9b38"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);
