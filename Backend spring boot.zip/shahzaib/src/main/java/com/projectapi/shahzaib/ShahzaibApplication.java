package com.projectapi.shahzaib;
import java.io.IOException;
import org.springframework.boot.SpringApplication;
import com.google.auth.oauth2.GoogleCredentials;

import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import java.io.InputStream;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.CrossOrigin;
@SpringBootApplication
@CrossOrigin(origins = "http://localhost:3000")

public class ShahzaibApplication {
    public static void main(String[] args) throws IOException {
        try {
            if (FirebaseApp.getApps().isEmpty()) {
                initializeFirebaseApp();
            } else {
                initializeFirebaseAppWithDifferentName();
            }
            SpringApplication.run(ShahzaibApplication.class, args);
        } catch (NullPointerException e) {
            System.err.println("File not found: " + e.getMessage());
            return;
        }
    }
    private static void initializeFirebaseApp() throws IOException {
        ClassLoader classLoader = ShahzaibApplication.class.getClassLoader();
        InputStream serviceAccount = classLoader.getResourceAsStream("authappkey.json");

        FirebaseOptions options = new FirebaseOptions.Builder()
                .setCredentials(GoogleCredentials.fromStream(serviceAccount))
                .build();
        FirebaseApp.initializeApp(options);
    }
    private static void initializeFirebaseAppWithDifferentName() throws IOException {
        ClassLoader classLoader = ShahzaibApplication.class.getClassLoader();
        InputStream serviceAccount = classLoader.getResourceAsStream("authappkey.json");

        FirebaseOptions options = new FirebaseOptions.Builder()
                .setCredentials(GoogleCredentials.fromStream(serviceAccount))
                .build();
        FirebaseApp.initializeApp(options, "mdapp");
    }
}

