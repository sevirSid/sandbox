package com.projectapi.shahzaib;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import org.springframework.stereotype.Service;
import com.google.api.core.ApiFuture;
import com.google.cloud.firestore.CollectionReference;
import com.google.cloud.firestore.DocumentReference;
import com.google.cloud.firestore.DocumentSnapshot;
import com.google.cloud.firestore.Firestore;
import com.google.cloud.firestore.QueryDocumentSnapshot;
import com.google.cloud.firestore.QuerySnapshot;
import com.google.firebase.cloud.FirestoreClient;
@Service
public class CRUDService {
    public String createCRUD(CRUD crud) throws ExecutionException, InterruptedException {
        Firestore dbFirestore = FirestoreClient.getFirestore();
        ApiFuture<com.google.cloud.firestore.WriteResult> collectionsApiFuture = dbFirestore.collection("crud_user").document(crud.getName()).set(crud);
        return collectionsApiFuture.get().getUpdateTime().toString();
    }

    public CRUD getCRUD(String documentId)  throws ExecutionException, InterruptedException {
        Firestore dbFirestore = FirestoreClient.getFirestore();
        DocumentReference documentReference = dbFirestore.collection("crud_user").document(documentId);
        ApiFuture<DocumentSnapshot> future = documentReference.get();
        DocumentSnapshot document = future.get();
        CRUD crud;
        if(document.exists()){
            crud = document.toObject(CRUD.class);
            return crud;
        }
        return null;
    }

    public String updateCRUD(CRUD crud) throws ExecutionException, InterruptedException{
        Firestore dbFirestore  = FirestoreClient.getFirestore();
        ApiFuture<com.google.cloud.firestore.WriteResult> collectionApiFuture = dbFirestore.collection("crud_user").document(crud.getName()).set(crud);
        return collectionApiFuture.get().getUpdateTime().toString();
    }

    public String deleteCRUD(String documentId) {
        Firestore dbFirestore = FirestoreClient.getFirestore();
        ApiFuture<com.google.cloud.firestore.WriteResult> writeResult = dbFirestore.collection("crud_user").document(documentId).delete();

        return "Succesfully Deleted" + documentId;
    }

    public boolean checkPhoneNumberExists(String phoneNumber) throws ExecutionException, InterruptedException {
        Firestore dbFirestore = FirestoreClient.getFirestore();
        CollectionReference usersRef = dbFirestore.collection("crud_user");
        ApiFuture<QuerySnapshot> future = usersRef.whereEqualTo("phoneNumber", phoneNumber).get();
        return future.get().getDocuments().size() > 0;
    }



public CRUD getRequestForVerification(String phoneNumber) {
    Firestore dbFirestore = FirestoreClient.getFirestore();
    CollectionReference requestsRef = dbFirestore.collection("verification_requests");
    
    // Query the database to find the request for the given phone number
    com.google.cloud.firestore.Query query = requestsRef.whereEqualTo("phoneNumber", phoneNumber);
    ApiFuture<QuerySnapshot> querySnapshot = query.get();
    
    try {
        // Iterate through the query results
        for (DocumentSnapshot document : querySnapshot.get().getDocuments()) {
            // Map the document snapshot to a CRUD object
            CRUD crud = document.toObject(CRUD.class);
            return crud;
        }
    } catch (InterruptedException | ExecutionException e) {
        e.printStackTrace();
       
    }
    
    
    return null;
}

public void storeRequestForVerification(CRUD request) {
    Firestore dbFirestore = FirestoreClient.getFirestore();
    DocumentReference docRef = dbFirestore.collection("verification_requests").document(request.getPhoneNumber());
    
    // Convert the CRUD object to a map for storing in Firestore
    Map<String, Object> requestData = new HashMap<>();
    requestData.put("phoneNumber", request.getPhoneNumber());
    requestData.put("generatedOTP", request.getGeneratedOTP());
    // Add more fields as needed
    
    try {
        // Synchronously store the request data in Firestore
        ApiFuture<com.google.cloud.firestore.WriteResult> result = docRef.set(requestData);
        com.google.cloud.firestore.WriteResult writeResult = result.get();
        
      
        System.out.println("Verification request stored successfully. Write time: " + writeResult.getUpdateTime());
    } catch (InterruptedException | ExecutionException e) {
     
        System.err.println("Error storing verification request: " + e.getMessage());
      
    }

}
public CRUD getUserByPhoneNumber(String phoneNumber) {
        try {
            Firestore dbFirestore = FirestoreClient.getFirestore();
            // Query Firestore to find the user with the given phone number
            QuerySnapshot querySnapshot = dbFirestore.collection("crud_user")
                                                    .whereEqualTo("phoneNumber", phoneNumber)
                                                    .limit(1)
                                                    .get()
                                                    .get();

            // Check if the query returned any documents
            if (!querySnapshot.isEmpty()) {
                // Get the first document (assuming only one user per phone number)
                QueryDocumentSnapshot documentSnapshot = querySnapshot.getDocuments().get(0);

                // Map Firestore document to a CRUD object
                CRUD user = documentSnapshot.toObject(CRUD.class);

                return user;
            } else {
                // No user found with the given phone number
                return null;
            }
        } catch (Exception e) {
            // Handle any exceptions
            e.printStackTrace();
            return null;
        }
    }




}