package com.projectapi.shahzaib;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Getter
@Setter
@NoArgsConstructor
public class CRUD {
 
    private Long documentId;
    private String name;
    private String email;
    private String phoneNumber;
    private String password;
    private String confirmPassword;
    private String generatedOTP;
    // Constructor with fields (if needed)
    public CRUD(String name, String email, String phoneNumber, String password, String confirmPassword) {
        this.name = name;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.password = password;
        this.confirmPassword = confirmPassword;
    }

   // Setter for generatedOTP
   public void setGeneratedOTP(String generatedOTP) {
    this.generatedOTP = generatedOTP;
}

// Getter for enteredOTP
public String getEnteredOTP() {
    // Assuming enteredOTP is stored as a field in the class
    // Replace with actual implementation if needed
    return null; // Placeholder implementation
}

// Getter for generatedOTP
public String getGeneratedOTP() {
    return generatedOTP;
}

// Method to convert CRUDRequest object to CRUD object
public CRUD toCRUD() {
    // Assuming no conversion is needed, returning 'this'
    return this;
}
}
