package com.projectapi.shahzaib;
import org.springframework.web.bind.annotation.RestController;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthException;
import com.google.firebase.auth.FirebaseToken;
import java.util.concurrent.ExecutionException;
import io.jsonwebtoken.Jwts;
// import java.security.SignatureException;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.apache.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.GetMapping;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.security.*;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import org.springframework.beans.factory.annotation.Value;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.util.Base64;
import java.io.IOException;


@RestController
public class CRUDController {
    public CRUDService crudService;
    public CRUDController(CRUDService crudService) {
        this.crudService = crudService;
    }
   
    @PostMapping("/signup")
    public ResponseEntity<String> createCRUD(@RequestBody CRUD request) throws InterruptedException, ExecutionException {
        boolean phoneNumberExists = crudService.checkPhoneNumberExists(request.getPhoneNumber());
        if (phoneNumberExists) {
            return ResponseEntity.status(HttpStatus.SC_BAD_REQUEST).body("Phone number already exists.");
        }
        if (!request.getPassword().equals(request.getConfirmPassword())) {
            return ResponseEntity.status(HttpStatus.SC_BAD_REQUEST).body("Password and confirm password do not match.");
        }
    
        // Store the request directly without OTP verification
        crudService.createCRUD(request);
    
        return ResponseEntity.ok("CRUD entry created successfully.");
    }
    
    @PostMapping("/login")
    public ResponseEntity<String> login(@RequestBody CRUD request)throws InterruptedException, ExecutionException {
        // Check if the phone number exists
        boolean phoneNumberExists = crudService.checkPhoneNumberExists(request.getPhoneNumber());
        if (!phoneNumberExists) {
            return ResponseEntity.status(HttpStatus.SC_BAD_REQUEST).body("Phone number not registered.");
        }
        
        // Retrieve the stored user based on the provided phone number
        CRUD storedUser = crudService.getUserByPhoneNumber(request.getPhoneNumber());

        // Check if the provided password matches the stored password
        if (!storedUser.getPassword().equals(request.getPassword())) {
            return ResponseEntity.status(HttpStatus.SC_UNAUTHORIZED).body("Incorrect password.");
        }

        // Login successful
        return ResponseEntity.ok("Login successful.");
    }
  

    @PostMapping("/authenticate")
    public String authenticateUser(@RequestBody String firebaseToken) throws InterruptedException, ExecutionException, NoSuchAlgorithmException, InvalidKeySpecException, SignatureException{
        try {
            // Validate Firebase Token
            FirebaseToken decodedToken = FirebaseAuth.getInstance().verifyIdToken(firebaseToken);
            
            // Extract user information from Firebase Token
            String userId = decodedToken.getUid();
            
            // Generate JWT
            String jwt = generateJWT(userId);
            
            // Return JWT to ReactJS client
            return jwt;
        } catch (FirebaseAuthException e) {
            // Handle authentication error
            e.printStackTrace();
            return "Authentication failed";
        }
    }

    private String generateJWT(String userId) throws InterruptedException, ExecutionException, NoSuchAlgorithmException, InvalidKeySpecException {
        try {
            // Firebase private key (directly included here)
            String firebasePrivateKeyBase64 = "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQDb+FHVOy/scFmCb5FxVP3+Ot5OzxvlMSBAos6aYF0ZGVBk9xnwXQMa6KHFi4eYC8yvVdYKDSP82qx696XTrfap7ET50PimJAixCb2f8x3/2z8cPl3FUaTyayTPsGodJWmyzWM0NCUldsAZ1tEy2ZbwWi3gfVqzcFIhyEVO8ZedBAQRkAWUiyKcVhCTwWpKxnfv2mXdKufLsoTEUeMPbgPveNVt/YwSBgi5JKl+W1/lmPYplVar4lfQD/zew6gG9j2zAT70R7qgBlIj05TqqLc038OfIq3vZGUAxViHM1+o7eXii4H9jG1PhuMmvsNyqnKgQ1Y0rWTdRqXqPsvDFhfrAgMBAAECggEAINSztg0i7nmoSmkHfrBORoMXyhBsW+1UoIEMMAtg6c2W67Lbyr2/KGV/O6JDJyTftG2tyAtFC0jCBIpw1CK7VYo/kz+m1Pk82NuY00YwfI8HINqIGVrBsTLfqCXu+JGscHTqMRD1WF2cd17SE3JZbl8vSLm871o8z/D5szooxFTdvixg7SO85eu+bwHrpm1PeKDhMXDQS7sClavWvS/I9b5r2gnfmn9S4V4SvcHzhvQ2pKenCuWwM3WT1b52Mte8alO8TPj5rbcU8bdb5EqpHl/uFSVfsuLohLh3ThPYCWTf8tG0fIyBBmZytxbeRPINCCYF5XFjQmgGa/FGAMVT0QKBgD0k7ZM6U3kL9Mz7TrkRaTmX4KezE7JpuLmWUwUErEl28bP70CNTgn6jlmuFZL2Zi9h5lRnBeHBtYaHBpl5vjR/hItDqGVaXGeRx/Uf8LRiVXqSVztFXM9MedydNeI00LChXpad6EPzjP8nQLtioge0TIQ3joqFBxuDfOEWAqGvMQKBgQDmPmTFEuosYyapixnn/DvVsNbSCVyGFYt43qo/qAuF7etf5Mod3HGwHRR+93DLW1QGKoN1tmSWID+LFmghjoUEdt/bRQvUCx8RXbTGgseNyEwe+L+Q3tTQTWjya91QjVZ5qljBNzBh63oOYMvYX3XR8A54u78q2bvHGfOE40SJ2wKBgEIpp3pc7t5Y9bipZ3ITSQ2tLsfIm1O/2sfXxlXzzIpiTwE3Ru4y+04VrjsCyRPxBsZkKdcI506gzbi/V0tw4gDRGV9/MZPlRXtRbYVrd1DWsObfxD/6YHXezYiV6BDDl9S/ot0q1R8QuIGk6ExBavYicO4amGxuRMooQTfUFGsxAoGAAeaP9GSElFs5LXsdeqHFaK0uCMvU/LJe1V+ZLi9X8QIWyFLeLELumVKUIbwvLS6S0f412Zno2Khpfd9wep5vkKrejDPUtiplVkJcxKq9tPjrT/IjurFsNk/9RssHJ6wTA6wZUXcAKj7EYiwAYsfe9B20MODz4gmsGCepr/YkUbMCgYEA2uFmYErWEi/iylfbwT/dy0WEqJL4CPPZKO6ucW6Cdv/9zuwRSzwdQtU9rhqkZHMp6tS2MDbVxUvSCVoCKZ7rDTQa02EIZK5Kci4lHsBkan8dzcEWq4QsjnxG8m5VXKmZw2jgMKBgnD1aextUo83S1fSGv3g30RFGcbRqkxivia0=";
                    

            // Create a KeyFactory instance for RSA
            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            
            // Decode the Base64-encoded private key bytes
            byte[] privateKeyBytes = Base64.getDecoder().decode(firebasePrivateKeyBase64);
            
            // Generate a private key object using PKCS8EncodedKeySpec
            PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(privateKeyBytes);
            PrivateKey privateKey = keyFactory.generatePrivate(keySpec);
            
            // Build and sign the JWT
            return Jwts.builder()
                    .setSubject(userId)
                    .signWith(privateKey)
                    .compact();
        } catch (IllegalArgumentException | NoSuchAlgorithmException | InvalidKeySpecException e) {
            // Handle the exception gracefully
            e.printStackTrace();
            throw new IllegalArgumentException("Failed to generate JWT: " + e.getMessage());
        }
    }


    // private String generateJWT(String userId) throws InterruptedException, ExecutionException, NoSuchAlgorithmException, InvalidKeySpecException, SignatureException {
    //     try {
    //         // Firebase service account JSON credentials
    //         String firebasePrivateKeyBase64 = "-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCV2n3ZZ2thFnkp\n2Wcz3lOQJMhzcfpaJif/Nt9o+8xFAAeWg3sUA8waW6XH/1VXJHYmSNKuPaDAflwH\ni3XSqBQVxhvzLOlHtKkvuH1aJLxmkN+QIOHPLjBXBkq9bXH4Oa2Gi9VGwl0KMapJ\nszkDikj/MzA8t+u3qgYDB4MPkTcX8/2NBvKAo6ZPkIywu1/UdqJm4+e8O2/u9MSb\nRzk8r4uVe+DzXCCoCdmr99QHO79eAcSNR7+hScWWZXg+cEWAUd6AYyvTlG43lV+8\nrky4wOzdnHvrheKbSa1J67oF/nHsauZNI8n1DbCJY+UR5KHZIygWxeQCmCwu02Sv\nfiENqgLDAgMBAAECggEALSqKrgE+2ydz44o0Uezb0OFVTX54D73aZlD6q2DhY5ar\nstD0QscWOIeRAyPRbA+AUO+4GG5YykwLnvaIz7J7Q0jP2c6ajVNFfy2jEo1p/5wA\n1icjCFgKl+A8nLWlGUUBKUFySf6BHnZztfz/3TJL6CdcjaB9uoDTiQw1k3aYXW5l\npcykOAvNjnbvJjFJWJOLry6SSBuiMM9aQe4fmmlD6+F6nUTSjHpQYL1Dqxt3LAO7\n9aFA7lQq0gzCU/eqBoopNmoEqLVISBTGqrWZYskbc22l49FJRHoZDwbOyem6S7ZO\nJl4Q6nb+RetdMKo8h/J7apu2+NTlntf2EGaGXEgiOQKBgQDPWkfvQSdMW7iQc+5z\ndroIZZwbaw2ZiOy7fw+kfp7n0wryigmNixDRFRb3R2XhUJ3Ra2ZeEvo43gtXBqej\nqARttjeZNe9m0GruVTdw3/q2use4Sywj4s/HhB6SgqvJ7lRc0A/p0cCCJuu03Vsq\n2bn8PJ0JglvLjiLvoctwn/cLlwKBgQC5Asb4TQC3s7ylA8HzvgFj4yhxFRw73rv8\nL3U2TvxuPt2OWtCJKz5b2BXF3rr/YR0VoJaOLss5vz1DR81tcd0hxxvP9ZRS02hN\n+mBEplcdY2w5Zr2nKYxEmYtlvOJ/R3+8UnmiXQbZsRpUhNhMXqQihQ/pLXYvuETg\ng3v85TXXtQKBgQCrNu39Fjx/5aCxzriPqPKV6mkLjssNAy4O6C0fc9p8rBv3B5o5\nwSHis1piVxc+BFY8TUWa2mq5OEf+1STpktwNR5ADN7D1oZUaNU1xK9EWv4YYnCHX\ng/pz0Zl4+uMk+2G3vanWNXeTQNYSY1FbQas8J0S4TGbF3xjj7CJTXhMdAwKBgE+N\nVijmU2yqKG98EiXQiaB9yKH3RdCokYR6k5fqlriA55uSiSCyK3oqjBItF5NAGtV1\n28b/b/tAtAL+GOL6lu8zQk5FdqW2qZ7+De7253aHjb2Q4/PA9cN5kmsIsQuxnsdH\nX23lOlDYyk2VYbxU5ZbCSHknRy51uYgggWvY0zIRAoGABA9XHsOhgqBMXF+6V3d9\n6EmApAwO0cXMywWc7mE63aHmWWqCtZxzFMsZtYqUDb9MmOqBgTWE/C7nwt8VSPyw\n/ttaxMBbIY1o8z5QQpoEh+2LIKhfLzoAULiiViu2zaC7KMS+4W+eWThzyjIYdDgR\najTDPHKYy2Od5Jwb7lCB3xo=\n-----END PRIVATE KEY-----\n";
            
    //         // Create a KeyFactory instance for RSA
    //         KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            
    //         // Decode the Base64-encoded private key bytes
    //         byte[] privateKeyBytes = Base64.getDecoder().decode(firebasePrivateKeyBase64);
            
    //         // Generate a private key object using PKCS8EncodedKeySpec
    //         PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(privateKeyBytes);
    //         PrivateKey privateKey = keyFactory.generatePrivate(keySpec);
            
    //         // Build and sign the JWT
    //         return Jwts.builder()
    //                 .setSubject(userId)
    //                 .signWith(privateKey)
    //                 .compact();
    //     } catch (IllegalArgumentException | NoSuchAlgorithmException | InvalidKeySpecException e) {
    //         // Handle the exception gracefully
    //         e.printStackTrace();
    //         throw new IllegalArgumentException("Failed to generate JWT: " + e.getMessage());
    //     }
    // }
    
    // private String generateJWT(String userId) throws InterruptedException, ExecutionException, NoSuchAlgorithmException, InvalidKeySpecException, SignatureException {
    //     try {
    //         // Load the private key from the resources folder
    //         String privateKeyPath = "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCV2n3ZZ2thFnkp2Wcz3lOQJMhzcfpaJif/Nt9o+8xFAAeWg3sUA8waW6XH/1VXJHYmSNKuPaDAflwHi3XSqBQVxhvzLOlHtKkvuH1aJLxmkN+QIOHPLjBXBkq9bXH4Oa2Gi9VGwl0KMapJszkDikj/MzA8t+u3qgYDB4MPkTcX8/2NBvKAo6ZPkIywu1/UdqJm4+e8O2/u9MSbRzk8r4uVe+DzXCCoCdmr99QHO79eAcSNR7+hScWWZXg+cEWAUd6AYyvTlG43lV+8rky4wOzdnHvrheKbSa1J67oF/nHsauZNI8n1DbCJY+UR5KHZIygWxeQCmCwu02SvfiENqgLDAgMBAAECggEALSqKrgE+2ydz44o0Uezb0OFVTX54D73aZlD6q2DhY5arstD0QscWOIeRAyPRbA+AUO+4GG5YykwLnvaIz7J7Q0jP2c6ajVNFfy2jEo1p/5wA1icjCFgKl+A8nLWlGUUBKUFySf6BHnZztfz/3TJL6CdcjaB9uoDTiQw1k3aYXW5lpcykOAvNjnbvJjFJWJOLry6SSBuiMM9aQe4fmmlD6+F6nUTSjHpQYL1Dqxt3LAO79aFA7lQq0gzCU/eqBoopNmoEqLVISBTGqrWZYskbc22l49FJRHoZDwbOyem6S7ZOJl4Q6nb+RetdMKo8h/J7apu2+NTlntf2EGaGXEgiOQKBgQDPWkfvQSdMW7iQc+5zdroIZZwbaw2ZiOy7fw+kfp7n0wryigmNixDRFRb3R2XhUJ3Ra2ZeEvo43gtXBqejqARttjeZNe9m0GruVTdw3/q2use4Sywj4s/HhB6SgqvJ7lRc0A/p0cCCJuu03Vsq2bn8PJ0JglvLjiLvoctwn/cLlwKBgQC5Asb4TQC3s7ylA8HzvgFj4yhxFRw73rv8L3U2TvxuPt2OWtCJKz5b2BXF3rr/YR0VoJaOLss5vz1DR81tcd0hxxvP9ZRS02hN+mBEplcdY2w5Zr2nKYxEmYtlvOJ/R3+8UnmiXQbZsRpUhNhMXqQihQ/pLXYvuETgg3v85TXXtQKBgQCrNu39Fjx/5aCxzriPqPKV6mkLjssNAy4O6C0fc9p8rBv3B5o5wSHis1piVxc+BFY8TUWa2mq5OEf+1STpktwNR5ADN7D1oZUaNU1xK9EWv4YYnCHXg/pz0Zl4+uMk+2G3vanWNXeTQNYSY1FbQas8J0S4TGbF3xjj7CJTXhMdAwKBgE+NVijmU2yqKG98EiXQiaB9yKH3RdCokYR6k5fqlriA55uSiSCyK3oqjBItF5NAGtV128b/b/tAtAL+GOL6lu8zQk5FdqW2qZ7+De7253aHjb2Q4/PA9cN5kmsIsQuxnsdHX23lOlDYyk2VYbxU5ZbCSHknRy51uYgggWvY0zIRAoGABA9XHsOhgqBMXF+6V3d96EmApAwO0cXMywWc7mE63aHmWWqCtZxzFMsZtYqUDb9MmOqBgTWE/C7nwt8VSPyw/ttaxMBbIY1o8z5QQpoEh+2LIKhfLzoAULiiViu2zaC7KMS+4W+eWThzyjIYdDgRajTDPHKYy2Od5Jwb7lCB3xo=";
            
    //         String firebasePrivateKeyBase64 = extractPrivateKeyFromJson(privateKeyPath);
    
    //         // Create a KeyFactory instance for RSA
    //         KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            
    //         // Decode the Base64-encoded private key bytes
    //         byte[] privateKeyBytes = Base64.getDecoder().decode(firebasePrivateKeyBase64);
            
    //         // Generate a private key object using PKCS8EncodedKeySpec
    //         PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(privateKeyBytes);
    //         PrivateKey privateKey = keyFactory.generatePrivate(keySpec);
            
    //         // Build and sign the JWT
    //         return Jwts.builder()
    //                 .setSubject(userId)
    //                 .signWith(privateKey)
    //                 .compact();
    //     } catch (IllegalArgumentException | NoSuchAlgorithmException | InvalidKeySpecException e) {
    //         // Handle the exception gracefully
    //         e.printStackTrace();
    //         throw new IllegalArgumentException("Failed to generate JWT: " + e.getMessage());
    //     }
    // }
    
    // private String extractPrivateKeyFromJson(String privateKeyPath) {
    //     try {
    //         // Read the contents of the JSON file from the resources folder
    //         InputStream inputStream = getClass().getClassLoader().getResourceAsStream(privateKeyPath);
    //         if (inputStream == null) {
    //             throw new IllegalArgumentException("File not found: " + privateKeyPath);
    //         }
    
    //         // Parse the JSON to extract the private key
    //         StringBuilder stringBuilder = new StringBuilder();
    //         try (BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream))) {
    //             String line;
    //             while ((line = bufferedReader.readLine()) != null) {
    //                 stringBuilder.append(line);
    //             }
    //         }
    //         return stringBuilder.toString();
    //     } catch (IOException e) {
    //         // Handle file reading errors
    //         e.printStackTrace();
    //         throw new IllegalArgumentException("Failed to read private key file: " + e.getMessage());
    //     }
    // }
    
    @GetMapping("/get")
    public CRUD getCRUD(@RequestParam String documentId)throws InterruptedException, ExecutionException {
        return crudService.getCRUD(documentId);
    }
    @PutMapping("update")
    public String updateCRUD(@RequestBody CRUD crud) throws InterruptedException, ExecutionException {
        return crudService.updateCRUD(crud);
    }
    
    @PutMapping("/delete")
    public String deleteCRUD(@RequestParam String documentId) {  
        return crudService.deleteCRUD(documentId);
    }
    
    @GetMapping("/test")
    public ResponseEntity<String> testGetEndpoint(){
        return ResponseEntity.ok("Test Get Endpoint is Working");
    }
}
